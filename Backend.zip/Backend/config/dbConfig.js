// Arrays to simulate database storage
const users = [];
const properties = [];
const tenants = [];
const expenses = [];
const incomes = [];

module.exports = {
  users,
  properties,
  tenants,
  expenses,
  incomes,
};